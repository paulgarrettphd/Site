document.addEventListener("click", e => {
    let handle
    if (e.target.matches(".handle")) {
      handle = e.target
    } else {
      handle = e.target.closest(".handle")
    }
    if (handle != null) onHandleClick(handle)
  })
  
  function onHandleClick(handle){ 
    const slider = document.getElementById('img_slider')
    const sliderIndex = parseInt( getComputedStyle(slider).getPropertyValue("--slider-index") )
    const itemCount = (slider.children.length )
    const itemsPerScreen = parseInt( getComputedStyle(slider).getPropertyValue("--items-per-screen") )
    const sliderItemCount = Math.ceil(itemCount / itemsPerScreen)
  
    if (handle.classList.contains("left-handle")) {
      if (sliderIndex - 1 < 0){ 
        slider.style.setProperty("--slider-index", sliderItemCount - 1)
      } else { 
        slider.style.setProperty("--slider-index", sliderIndex - 1)
      }
    }
  
    if (handle.classList.contains("right-handle")) {
      if (sliderIndex + 1 >= sliderItemCount){ 
        slider.style.setProperty("--slider-index", 0)
      } else { 
        slider.style.setProperty("--slider-index", sliderIndex + 1)
      }
    }
    document.getElementById('date_slider').style.setProperty("--slider-index", parseInt( getComputedStyle(slider).getPropertyValue("--slider-index") ) )
    document.getElementById('event_slider').style.setProperty("--slider-index", parseInt( getComputedStyle(slider).getPropertyValue("--slider-index") ) )
    document.getElementById('desc_slider').style.setProperty("--slider-index", parseInt( getComputedStyle(slider).getPropertyValue("--slider-index") ) )
    
  
  }