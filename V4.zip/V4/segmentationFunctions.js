// Add Submission Button to images. 
//   -- Add On Click function for submit
//   -- Set all order from 1:X on submission
//   -- Set different event colors
// exif library for image data

var optionsPeople = ['Alone', 'Family', 'Friends','Colleagues','Classmates', 'Pet(s)',
'Strangers', 'Crowd', 'Partner'];

var optionsActive = ['Watching Movies/TV/Concert/Performance','Exercising/Sport/Dancing/Walking/Running',
'Reading/Writing','Eating/Drinking','Work (Study/Desk Work)','Other Non-Desk Work',
'Meeting/Talking','Chores','Transiting','Shopping','Social Media','Praying/Meditating',
'Sleeping/Napping', 'Personal Grooming/Hygiene'];

var optionsPlace = ['Home','Work', 'Store','Library','Park','Restaurant/Cafe',
'Office','Gymnasium', 'Garden','Church', 'Beach','School', 'Farm',
'Sports Field','Street','In Transport'];

var descPeople = []
var descActivities = []
var descPlaces = []

var eventOrderSelect = []
var eventEventGrouping = []

var toggleEventButtons ;
var toggleSurvey = 0;
var eventStartLog = [];
var eventEndLog = [];

var imageStatus = []
var imgColors = []
var imageDeleteToggle = true


function initVectors(){ 
  for (let ii = 0; ii < images.length; ii++){
    descPeople.push('')
    descActivities.push('')
    descPlaces.push('')
    eventOrderSelect.push(-1)
    imageStatus.push('deselected')
    imgColors.push('')
  }
}
initVectors()

// Update with Delete Img Function
function image_click(idx){ 
  // if (imageDeleteToggle == true && (imageStatus[idx] == 'deselected' || imageStatus[idx] == 'complete')  ){
  if (imageDeleteToggle == true && !imageStatus.includes( 'event_start' ) && !imageStatus.includes( 'selected' ) ){
    imageDeleteToggle = false
    document.getElementById('img' + idx).style.backgroundColor = 'red'
    document.getElementById("carouselEventButtons").style.display = 'none'
    var container = document.getElementById("carouselSurvey");
    container.insertAdjacentHTML('beforeend',
    `<div class='delete-buttons'> 
      <button onclick="eventDeleteButtonClick(` + idx + `)" name = 'event-delete' id = "delete-image" > Delete Image </button>
      <button onclick="eventDeleteButtonCancel()" name = 'event-delete-cancel' id = "delete-cancel" > Cancel </button>
      </div>`)
  }
}

function updateImgColors(){
  var sorted = eventStartLog.slice(0).sort(function(a, b){return a-b});

  colorIdx = 0
  for (ii = 0; ii < sorted.length; ii++){ 
    end = eventEndLog [ eventStartLog.indexOf(sorted[ii]) ]
    start = sorted[ii]

    if (colorIdx > 2 ){
      colorIdx = 0
    }

    for (kk = start; kk <= end; kk++){
      imgColors[kk] = ImgColors[colorIdx]
    }
    colorIdx ++

  }
}

function eventDeleteButtonClick(idx){
  imageStatus[idx] = 'delete'
  orderMax = Math.max.apply(Math, eventOrderSelect ) + 1
  eventOrderSelect[idx] = orderMax
  eventDeleteButtonCancel()
}

function eventDeleteButtonCancel(){
  imageDeleteToggle = true
  document.getElementById("carouselEventButtons").style.display = 'flex'
  document.getElementsByName('event-delete').forEach(function(item) { item.remove()} )
  document.getElementsByName('event-delete-cancel').forEach(function(item) { item.remove()} )
  updateDisplay(0)
}

function eventStartButtonClick(idx){
  eventStartLog.push(idx); 
  imageStatus[idx] = 'event_start'
  updateDisplay(idx)

}

function eventEndButtonClick(idx){
  eventEndLog.push(idx); 
  imageStatus[idx] = 'selected'
  for (ii = eventStartLog[eventStartLog.length - 1]; ii <= idx; ii ++ ){
    if (imageStatus[ii] != 'delete'){
      imageStatus[ii] = 'selected'
    }
  }
  updateDisplay(idx)
  showSurvey()  
}

function undoDelete(idx){
// Undo delete & get data from surounding images 
//  if between completed events.
 [start, end] = getEventBounds(idx)
//  console.log('Start & End:', start, end)
 if (start == 'na'){
    imageStatus[idx] = 'deselected'
    eventOrderSelect[idx] = -1
 } 
 if (start == idx && end == idx){
  imageStatus[idx] = 'deselected'
  eventOrderSelect[idx] = -1
 }
 else if (start <= idx && end >= idx){
    imageStatus[idx] = 'complete'
    if (start == idx){
      val = end
    } else if (end == idx) {
      val = start
    } else {
      val = start
    }
    descActivities[idx] = descActivities[val]
    descPeople[idx] = descPeople[val]
    descPlaces[idx] = descPlaces[val]
    eventOrderSelect[idx] = eventOrderSelect[val]
  }  else {
    imageStatus[idx] = 'deselected'
    eventOrderSelect[idx] = -1
  }
  updateDisplay(idx)
}

function getEventBounds(idx){
  var sorted = eventStartLog.slice(0).sort(function(a, b){return a-b});
  if (sorted.length > 0){
    for (ii = 0; ii < sorted.length; ii++){ 
      if (sorted[ii] <= idx ){ 
        end = eventEndLog [ eventStartLog.indexOf(sorted[ii]) ]
        if (end >= idx){
          start = eventStartLog[ eventStartLog.indexOf(sorted[ii]) ]          
        }
      }
    }
  return [start, end]
  }
  return ['na', 'na']
}

function undoEvent(idx){
  [start, end] = getEventBounds(idx)
  // console.log(start, end)

  for (ii = start; ii <= end; ii++ ){
    if (imageStatus[ii] != 'delete'){
      imageStatus[ii] = 'deselected'
      descPeople[ii] = ''
      descActivities[ii] = ''
      descPlaces[ii] = ''
    }
  }

  eventStartLog.splice(eventStartLog.indexOf(start), 1); 
  eventEndLog.splice(eventEndLog.indexOf(end), 1); 
  updateDisplay(idx)
}

function getNextEventStart(idx){
  var sorted = eventStartLog.slice(0).sort(function(a, b){return a-b});
    var maxidx = images.length
    if (sorted.length > 0){
      var count = 0
      while (true){
        if ( sorted[count] > idx ){
          maxidx = sorted[count]
          break
        }
        if ( count > sorted.length){
          maxidx = images.length
          break
        }
        count += 1
      }
    }
    return maxidx
  }

function updateDisplay(idx){
  // console.log('Image Status:', imageStatus)
  // console.log('Order Selected:', eventOrderSelect)
  // console.log('Activity Selected:', descActivities)

  if (imageStatus.filter(x => x=='complete' || x =='delete').length == images.length){
    document.getElementById('submitAll').style.display = 'flex'
  } else {
    document.getElementById('submitAll').style.display = 'none'
  }

  var Start = document.getElementsByName('event-button-start')
  var End = document.getElementsByName('event-button-end')
  var PreStart = document.getElementsByName('event-button-NA')
  var Complete = document.getElementsByName('event-button-complete')
  var Delete = document.getElementsByName('undo-delete')

  // Phase between selecting first event bound & prior to selecting event end.
  if (imageStatus.includes('event_start')){
    var maxidx = getNextEventStart(idx)
    var CurrentImg = document.getElementById('img' + idx)
    CurrentImg.style.backgroundColor = 'lime'
    Start.forEach(function(item) { item.style.display = 'none'} )
    Delete.forEach(function(item) { item.style.display = 'none'} )
    Complete.forEach(function(item) { item.style.display = 'none'} )

    PreStart.forEach(function(item, index){ 
      if (index < idx){
        item.style.display = 'inline-block'
      } else{
        item.style.display = 'none'
      }
    })

    End.forEach(function(item, index){ 
      if (index < maxidx && index >= idx && imageStatus[index] != 'delete'){
        item.style.display = 'inline-block'
      } else{
        item.style.display = 'none'
      }
    })

    Complete.forEach(function(item) { item.style.display = 'none'} )
    Delete.forEach(function(item) { item.style.display = 'none'} )

    return
  }

  // Phase during the survey presentation
  else if (imageStatus.includes('selected')) {
    [startIdx, endIdx] = getEventBounds(idx)
    updateImgColors()
    for (ii = 0; ii < imageStatus.length; ii++){
      if (imageStatus[ii] == 'selected'){
          img = document.getElementById('img' + ii)
          img.style.backgroundColor = 'lime'
      }
    }

    document.getElementById('carouselHandles').style.display = 'none';
    document.getElementById("carouselDescriptions").style.display = 'none';
    Delete.forEach(function(item) { item.style.display = 'none'} )
    Start.forEach(function(item) { item.style.display = 'none'} )
    End.forEach(function(item) { item.style.display = 'none'} )
    Complete.forEach(function(item) { item.style.display = 'none'} )
    PreStart.forEach(function(item) { item.style.display = 'none'} )
    return
  }

  // Phase after the survey awaiting an event button response.
  else {
    updateImgColors()
    for (ii = 0; ii < imageStatus.length; ii++){
      // console.log(ii, imageStatus[ii])
      var CurrentImg = document.getElementById('img' + ii)
      var status = imageStatus[ii]
      if (status == 'delete'){
        // console.log('EVENTS DELETED')
        CurrentImg.style.backgroundColor = 'red'
        Delete[ii].style.display = 'flex'
        Start[ii].style.display = 'none'
        End[ii].style.display = 'none'
        PreStart[ii].style.display = 'none'
        Complete[ii].style.display = 'none'
        document.getElementById("desc"+ii).innerText = ''
      } 
      else if (status == 'complete'){
        // console.log('EVENTS COMPLETE')
        CurrentImg.style.backgroundColor = imgColors[ii]
        Delete[ii].style.display = 'none'
        Start[ii].style.display = 'none'
        End[ii].style.display = 'none'
        PreStart[ii].style.display = 'none'
        Complete[ii].style.display = 'inline-block'
        desc = descActivities[ii].replace(',', ' \r\n' ) + ' \r\n ' + 
               descPeople[ii].replace(',', ' \r\n' ) + ' \r\n ' + 
               descPlaces[ii].replace(',', ' \r\n' )
        document.getElementById("desc"+ii).innerText = desc
      } 
      else if (status == 'deselected'){
        // console.log('EVENTS DESELECTED')
        CurrentImg.style.backgroundColor = 'gray'
        Delete[ii].style.display = 'none'
        Start[ii].style.display = 'inline-block'
        End[ii].style.display = 'none'
        PreStart[ii].style.display = 'none'
        Complete[ii].style.display = 'none'
        document.getElementById("desc"+ii).innerText = ''
      }
    }
  } 
  return
}

function showSurvey(){


  idxS = eventStartLog[eventStartLog.length - 1];
  idxE = eventEndLog[eventEndLog.length - 1];

  eventID = idxS + '_' + idxE

  var HTMLstrPeople = ''
  for (var ii = 0; ii < optionsPeople.length; ii++){
    HTMLstrPeople += `<div>
    <input type="checkbox" id="` + 
    optionsPeople[ii] + '_' + eventID + `" name="` + 
    'checkbox_' + eventID +`" value="` + 
    optionsPeople[ii] + `" label = '` + 
    optionsPeople[ii] + '_' + eventID + `'><label for="` + 
    optionsPeople[ii] + '_' + eventID + `">` +  optionsPeople[ii]  + `</label>
    </div> ` 
  }

  var HTMLstrActive = ''
  for (var ii = 0; ii < optionsActive.length; ii++){
    HTMLstrActive += `<div>
    <input type="checkbox" id="` + 
    optionsActive[ii] + '_' + eventID + `" value="` + 
    optionsActive[ii] + `" label = '` + 
    optionsActive[ii] + '_' + eventID + `'><label for="` + 
    optionsActive[ii] + '_' + eventID + `">` +  optionsActive[ii]  + `</label>
    </div> ` 
  }

  var HTMLstrPlaces = ''
  for (var ii = 0; ii < optionsPlace.length; ii++){
    HTMLstrPlaces += `<div>
    <input type="checkbox" id="` + 
    optionsPlace[ii] + '_' + eventID + `" value="` + 
    optionsPlace[ii] + `" label = '` + 
    optionsPlace[ii] + '_' + eventID + `'><label for="` + 
    optionsPlace[ii] + '_' + eventID + `">` +  optionsPlace[ii]  + `</label>
    </div> ` 
  }


  HTMLstrPeople += '<div> <label for="Other People"> Other: </label> <input type="text" id="Input_OtherPeople_' + eventID  +  '" value = "" > </div>'

  HTMLstrActive += '<div> <label for="Other Activities"> Other: </label> <input type="text" id="Input_OtherActivity_' + eventID  +  '" value = "" > </div>'

  HTMLstrPlaces += '<div> <label for="Other Places"> Other: </label> <input type="text" id="Input_OtherPlace_' + eventID  +  '" value = "" > </div>'

  document.getElementById("carouselSurvey").insertAdjacentHTML('beforeend', 
                          '<button id="handle1" class="handle left-handle"> <div class="text">&#8249;</div> </button>' );

  document.getElementById("carouselSurvey").insertAdjacentHTML('beforeend', `<fieldset> 
      <legend>Select People:</legend>` + HTMLstrPeople + `</fieldset>` );

  document.getElementById("carouselSurvey").insertAdjacentHTML('beforeend', `<fieldset> 
      <legend>Select Activities:</legend>` + HTMLstrActive + `</fieldset>` )

  document.getElementById("carouselSurvey").insertAdjacentHTML('beforeend', `<fieldset>
      <legend>Select Places:</legend>` + HTMLstrPlaces + `</fieldset>` )

  document.getElementById('surveyFinish').style.display = 'flex';
  document.getElementById('surveyCancel').style.display = 'flex';
  document.getElementById("carouselSurvey").insertAdjacentHTML('beforeend', 
                          '<button id="handle2" class="handle right-handle"> <div class="text">&#8250; </div> </button>' );
   
    
}


function surveyComplete(){
  var peopleResponse = ''
  var placesResponse = ''
  var activitiesResponse = ''

  for (let ii = 0; ii < optionsPeople.length; ii++){
    rsp = document.getElementById(optionsPeople[ii] + '_' + eventID);
    if (rsp.checked){
      if (peopleResponse == ''){ peopleResponse = rsp.value }
      else { peopleResponse = peopleResponse + ', ' + rsp.value }
    }
  }

  for (let ii = 0; ii < optionsActive.length; ii++){
    rsp = document.getElementById(optionsActive[ii] + '_' + eventID);
    if (rsp.checked){
      if (activitiesResponse == ''){ activitiesResponse = rsp.value }
      else { activitiesResponse = activitiesResponse + ', ' + rsp.value }
    }
  }

  for (let ii = 0; ii < optionsPlace.length; ii++){
    rsp = document.getElementById(optionsPlace[ii] + '_' + eventID);
    if (rsp.checked){
      if (placesResponse == ''){ placesResponse = rsp.value }
      else { placesResponse = placesResponse + ', ' + rsp.value }
    }
  }

  if (document.getElementById( 'Input_OtherPeople_' + eventID  ).value != ''){
    if (peopleResponse == ''){
      peopleResponse = document.getElementById( 'Input_OtherPeople_' + eventID  ).value
    } else {
      peopleResponse = peopleResponse + ', ' + document.getElementById( 'Input_OtherPeople_' + eventID  ).value
    }
    document.getElementById( 'Input_OtherPeople_' + eventID  ).value = ''
  }


  if (document.getElementById( 'Input_OtherActivity_' + eventID  ).value != ''){
    if (activitiesResponse == ''){
      activitiesResponse = document.getElementById( 'Input_OtherActivity_' + eventID  ).value
    } else {
      activitiesResponse = activitiesResponse + ', ' + document.getElementById( 'Input_OtherActivity_' + eventID  ).value
    }
    document.getElementById( 'Input_OtherActivity_' + eventID  ).value = ''
  }

  if (document.getElementById( 'Input_OtherPlace_' + eventID  ).value != ''){
    if (placesResponse == ''){
      placesResponse = document.getElementById( 'Input_OtherPlace_' + eventID  ).value
    } else {
      placesResponse = placesResponse + ', ' + document.getElementById( 'Input_OtherPlace_' + eventID  ).value
    }
    document.getElementById( 'Input_OtherPlace_' + eventID  ).value = ''
  }

  if (peopleResponse == ''){ 
    alert("One or more 'people' descriptors must be added to continue.");
    return false
  }

  if (activitiesResponse == ''){ 
    alert("One or more 'activity' descriptors must be added to continue.");
    return false
  }

  if (placesResponse == ''){ 
    alert("One or more 'place' descriptors must be added to continue.");
    return false
  }

  orderMax = Math.max.apply(Math, eventOrderSelect ) + 1
  for (ii = eventStartLog[eventStartLog.length - 1]; ii <= eventEndLog[eventEndLog.length-1]; ii ++ ){
    if (imageStatus[ii] != 'delete'){
      imageStatus[ii] = 'complete'
      descPeople[ii] = peopleResponse
      descActivities[ii] = activitiesResponse
      descPlaces[ii] = placesResponse
      eventOrderSelect[ii] = orderMax
    }
    
  }
  
  // document.getElementsByName('event-button-NA').forEach(function(item){ item.style.display = 'none' })
  document.getElementById('handle1').remove()
  document.getElementById('handle2').remove()
  var legends = document.getElementsByTagName("legend");
  for(var ii=0; ii<legends.length; ii++){
    legends[ii].parentNode.style.display = 'none'
  }
  document.getElementById('surveyFinish').style.display = 'none';
  document.getElementById('surveyCancel').style.display = 'none';
  document.getElementById('carouselHandles').style.display = 'flex';
  document.getElementById("carouselDescriptions").style.display = 'flex';

  updateDisplay()
  return
}



function surveyCancel(){
  for (ii = eventStartLog[eventStartLog.length - 1]; ii <= eventEndLog[eventEndLog.length-1]; ii ++ ){
    imageStatus[ii] = 'deselected'
  }
  eventStartLog.pop()
  eventEndLog.pop()
  document.getElementById('handle1').remove()
  document.getElementById('handle2').remove()
  var legends = document.getElementsByTagName("legend");
  for(var ii=0; ii<legends.length; ii++){
    legends[ii].parentNode.style.display = 'none'
  }
  document.getElementById('surveyFinish').style.display = 'none';
  document.getElementById('surveyCancel').style.display = 'none';
  document.getElementById('carouselHandles').style.display = 'flex';
  document.getElementById("carouselDescriptions").style.display = 'flex';
  updateDisplay()
  return
}
