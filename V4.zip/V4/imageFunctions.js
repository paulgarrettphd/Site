var images = ['UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045407Z_b21ac850-8336-4163-b295-32e437733e4a.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045437Z_10a88046-68c5-42ab-bfb5-669aca788e52.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045507Z_f108caaf-59d0-4339-a51b-ff2d48cfeda6.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045537Z_c2e15a00-9f91-4077-8e4f-4ac19e6fc879.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045616Z_7a93ea82-78a6-4654-8a35-0a24bbb1d0f3.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045645Z_eb386568-e164-41a1-ac8c-8227f8fba338.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045729Z_30032fe1-7ecb-4271-9d05-bdfbb438f6a1.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045759Z_0d37a28b-f2a9-4257-a911-b58f2fd0fcb0.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045829Z_1bce4c9a-b43e-40c0-a09a-1841eba9b838.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045859Z_97defbfd-d695-4297-8db9-a2212ffa2a99.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045929Z_a3126ed5-5d99-4198-97b8-2533348632ce.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526045959Z_35615cb5-0078-4ee0-bda3-a21726f64fca.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050038Z_0026d8f9-b36c-4a1d-931c-96c636aca9ac.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050114Z_556aca03-9b27-428a-ac4e-3dd9903a4404.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050138Z_dcd50297-0c84-47a8-95c8-af3e67fbe30c.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050209Z_0764804c-058d-4c6c-b3e9-1b7a94dddc6b.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050239Z_12579848-c215-4f98-bc1c-f90c758ff652.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050309Z_333c34cf-deb2-48bd-9ab6-f90de837748a.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050339Z_f9c105ab-a1f6-4e37-b104-94a5eb8ca1b4.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050409Z_e1f48f88-7a88-417f-94c3-bb4ea6c2e0be.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050629Z_540b87e6-218b-43bb-bbbc-6e70d1cd4b79.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050650Z_223be944-9af9-4f7f-8188-d5ff6ce2fbf6.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-26-image_20220526050940Z_b32ff867-6598-40a9-812f-91d5ff8e40e3.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531060122Z_54e0aa02-cae6-440e-b8a3-f659405cb517.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531060335Z_e3bc91be-1504-4cd8-8bb1-376c508cbe4c.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531060522Z_88ce0276-9e18-49e9-a240-2029405df238.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531060711Z_d841fe53-43b9-4045-bb82-07a866d03081.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531060913Z_5b3c733a-10cb-468b-b97b-35bb9ed22527.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531061119Z_f46d0bc3-ff0d-40e8-b775-1994540f766c.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531061321Z_c71589e3-0396-4ab2-a741-d1d96c6c7b31.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531061721Z_816c98d2-9faf-4e1d-b038-1a96474e6847.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531062727Z_ea31874b-37db-44bc-bdd3-f1a90febb201.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531063100Z_9e1f89d2-4ff4-40c1-9b8a-7556d8beca4d.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531063222Z_ab19af27-5451-40e5-a9b0-1fe56a948e35.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531063722Z_eb746759-765e-4152-aaea-600a8f372be8.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531064221Z_ae524c6b-6dec-4193-9a15-a6b02d0bb160.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531064722Z_c186ad85-c902-4ec7-a28a-7ea30719c2db.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531064941Z_a3735fe8-18f3-4783-aae0-bb219d5530a8.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531065324Z_53c8e1d3-ca15-4ebc-9b83-e406db85a8a5.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531070458Z_3dcdde93-a53e-493a-bb21-46727a6c0466.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531070948Z_cc14f3dc-dcaa-4f1f-b2da-dba572ae4a3b.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531071446Z_d087a2a0-1987-4220-8963-783ee94b014d.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531071729Z_1893780e-8095-4795-912c-13de2f5588e4.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531072953Z_4fd08a80-a152-43e8-b5a0-6107da2b4b28.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531073448Z_bf401410-3f90-432c-abe2-448e394c1c0d.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531074525Z_e8f9a10c-ffc7-447f-823b-e75c7fb9ba0a.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531075006Z_fcc52487-c1dc-42ea-8d46-7acc66a7bb65.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531075230Z_8fb46cf9-15b2-43fb-945c-e5764f9d953a.jpeg',
'UFimages/https_--userhome-ap-northeast-1_356012f2-30b5-48ab-8eb2-55e4e24791b7-2022-05-31-image_20220531075447Z_a7c67086-8d4a-4d11-86c7-dc655274bee2.jpeg'
            ];

var imgDates = []
for (var ii = 0; ii < images.length; ii++ ){ imgDates.push( getDate ( images[ii].match(/\d{14}/g)[0] ) ) }

function getDate(dateString){
    year = dateString.slice(0,4)
    month = dateString.slice(4,6)
    day = dateString.slice(6,8)
    hour = dateString.slice(8,10)
    min = dateString.slice(10,12)
    sec = dateString.slice(12,14)
    dateString = new Date( month + '/' + day + '/' + year + ' ' + hour + ':' + min + ':' + sec + ' UTC' )
    dateString = formatAMPM(dateString)
    return(dateString)
  }
  
  function formatAMPM(date) {
    const months = ['January','February','March','April','May','June',
                    'July','August','September','October','November','December']
    var year = date.getFullYear()
    var month = months [ date.getMonth() ];
    var day = date.getDate()
    var DoW = ['Sununday','Monday','Tueday','Wednesday','Thursday','Friday','Saturday'][ date.getDay() ];
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = ('0' + minutes).slice(-2);
    if (parseInt( day ) == 1 ){ suffix = 'st of ' } 
    else if (parseInt( day ) == 2 ){ suffix = 'nd of '} 
    else { suffix = 'th of ' }
    var strTime = DoW + ' ' + day + suffix +  month + ', ' + year + '<br>' + hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }
  
  function imageButtonElements(imgList){
    var container = document.getElementById("img_slider");
    var datecontainer = document.getElementById("date_slider");
    var eventcontainer = document.getElementById("event_slider");
    var descontainer = document.getElementById("desc_slider");
    
    //eventcontainer.insertAdjacentHTML('beforeend', `<div class='event-buttons' > <button> Events Start </button>   </div>` ) 
    for (var ii = 0; ii < images.length; ii++) {
      datecontainer.insertAdjacentHTML('beforeend', '<div class="date-text">' + imgDates[ii]  + '</div>' )
      descontainer.insertAdjacentHTML('beforeend', `<div class="desc-text" id = 'desc` + ii + `'>  </div>` )
      container.insertAdjacentHTML('beforeend', `<img src="${imgList[ii]}" name='imgs' onclick="image_click(` + ii + `)" id = 'img` + ii + `' >  </img>` )
      eventcontainer.insertAdjacentHTML('beforeend', 
      `<div class='event-buttons'> 
      <button onclick="eventStartButtonClick(` + ii + `)" name = 'event-button-start' id = "event-start` + ii + `"> Event Start >> </button>
      <button onclick="undoDelete(` + ii + `)" name = 'undo-delete' id = "delete-undo` + ii + `"> Undo Deletion </button>
      <button onclick="eventEndButtonClick(` + ii + `)" name = 'event-button-end' id = "event-end` + ii + `"> << Event End </button>
      <button onclick="undoEvent(` + ii + `)" name = 'event-button-complete' id = "event-complete` + ii + `"> Labeled (Undo) </button>
      <button name = 'event-button-NA' id = "event-NA` + ii + `"> Before Event Start </button>
      </div>`)
    }
    document.getElementsByName('imgs').forEach( function(item){item.style.backgroundColor = 'gray'} )
  }

  
imageButtonElements(images)

var ImgColors = ['rgba( 100, 143, 255',
                 'rgba( 219, 39, 128',
                 'rgba( 255, 97, 0']

